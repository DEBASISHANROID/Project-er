package com.example.practice

 data class users (val name :String, val mail:String,val pass:String )