
package com.example.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


lateinit var   database: DatabaseReference
class mainactivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mainactivity2)


val singupbtn = findViewById<Button>(R.id.button)
val nme = findViewById<EditText>(R.id.name)
val pas = findViewById<EditText>(R.id.pass)
val  ml = findViewById<EditText>(R.id.mail)


   singupbtn.setOnClickListener {
       val name = nme.text.toString()
       val pas = pas.text.toString()
       val ml = ml.text.toString()

       val user =users(name , ml  , pas)
       database = FirebaseDatabase.getInstance().getReference("users")
       database.child((pas)).setValue(user).addOnSuccessListener {
           Toast.makeText(this , "Faild",Toast.LENGTH_SHORT).show()
       }
   }
    }
     }

